This is information about the command prompt shell

To begin with, run SETUP, which should configure cmdshell. Run it as an Administrator.

To revert the changes of this program, open the registry editor and delete the "shell" value inside HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Winlogon
Then log off and log back in and explorer should start as normal.

It is strongly recommended to use the Alt-Tab switcher to change between applications while in this environment

Keep in mind no UWP apps, such as settings, will work without the normal shell. Just run explorer before running these programs. If you want to kill explorer, type "ke" into the command prompt

To open the Quick Program Manager, type $$$ OR press Tab while the current directory inside command prompt is C:\windows\system32 (default). $$$.cmd should be the first file to appear (because Windows treats dollar signs like they are the first letter of the alphabet, and pressing Tab while in command prompt will go through all the files and folders in the current directory in alphabetical order)

If you want to change which programs are in the quick program manager, open the selp2.cmd / selp3.cmd files in a text editor (notepad) and change the file paths to the ones which you want. (the selp2/3.cmd files should be in C:\windows\cmdshell)
You should also change what message gets echoed to represent the new programs you have put in.

THIS PROGRAM WAS MADE BY FLIXTWIF
Sam Scranage @flixtwif on twitter/X.